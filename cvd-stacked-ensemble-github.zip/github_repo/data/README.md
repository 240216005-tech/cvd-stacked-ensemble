# Data

Place your CSV datasets here before running the pipeline.

## Required datasets

| File               | Source                                        |
|--------------------|-----------------------------------------------|
| kaggle_cvd.csv     | https://www.kaggle.com/datasets/sulianova/cardiovascular-disease-dataset |
| framingham.csv     | https://www.kaggle.com/datasets/dileep070/heart-disease-prediction-using-logistic-regression |

## UCI datasets (auto-downloaded)

Cleveland, Hungarian, and Statlog datasets are downloaded automatically
by `src/external_validation.py` from the UCI ML Repository.
